<?php
 include ('server_page.php');
 
 $b_name="";
 $a_email="";
 $c_picture="";
 $p_date="";
 $review="";
 $isbn="";
 $price="";
 $type="";
 $rating="";
 $book_format="";
 $paperback="";
 $hardback="";
 $ebook="";
 $availability="";
 
 if(isset($_GET['edit']))
 {
	 
	 $id=$_GET['edit'];
	 $query=mysqli_query($link,"select * from books where book_id=$id");
	 $res=mysqli_fetch_array($query);
	 
	 $b_name=$res['book_name'];
	 $a_email=$res['author_email'];
	 $c_picture=$res['cover_picture'];
	 $cat_array=GetArray("Select bkcat_id, cat_id from book_categories where book_id=$id order by cat_id");
	 $p_date=$res['dt_publish'];
	 $review=$res['review'];
	 $isbn=$res['isbn_number'];
	 $price=$res['price'];
	 $type=$res['type'];
	 $rating=$res['rating'];
	 $paperback=$res['is_paperback'];
	 $hardback=$res['is_hardback'];
	 $ebook=$res['is_ebook'];
	 $availability=$res['in_stock'];
 }

?>

<html>
<head>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script language="JavaScript" type="text/javascript">
$(function() {
		 $('#p_date').datepicker({
			dateFormat:"yy-mm-dd"
		});
	});
  $(document).ready(function(){
	  
	 $('#cancle').click(function(){
		window.location.assign("home_page.php");
	  });

	  if($.isNumeric($('#id').val())){
		  $('#myid').css({"display":"block"});
	  }

	  function display(input) {
   if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function(event) {
         $('#myid').attr('src', event.target.result);
      }
      reader.readAsDataURL(input.files[0]);
   }
}

$("#c_picture").change(function() {
	$('#myid').css({"display":"block"});
   display(this);
});
	  
  });
</script>
</head>
<body>
	
	<form method="POST" action="server_page.php" enctype="multipart/form-data" autocomplete="off">
	<input type="hidden" name="id" id="id" value="<?php echo $id ?>">
	<div name="div1" class="form-group" style="width:500px; margin-left:400px;">
		<h2> New Book</h2> <br> <br>
			<label> Book Name </label>
			<input type="text" class="form-control" name="b_name" id="b_name" value="<?php echo $b_name ?>" required>
			<br/>
		
			<label> Author Email </label>
			<input type="text" class="form-control" name="a_email" id="a_email" value="<?php echo $a_email ?>" required>
				<br/>

				<label> Cover Picture </label>
			<input type = "file" class="form-control" name="c_picture" id="c_picture" value="<?php echo $c_picture ?>" accept=".png, .jpg, .jpeg" required/>
			<img id = "myid" style="display:none;" src = "uploads/<?php echo $c_picture; ?>" class="img-thumbnail" /><br/>

			<label> Categories </label><br>
			<?php 
				foreach($category_arr as $key => $value){
					$present=0;
					if(isset($_GET['edit'])){
						foreach($cat_array as $cat_id){
							if($cat_id==$key){
								$present=1;
							}
						}
					}

					if($present==1){
						echo "&emsp;<input checked='checked' type='checkbox' name='categories[".$key."]' value='".$value."'>";
						echo "<label for='".$value."'>".$value."</label><br>";
					} else {
						echo "&emsp;<input type='checkbox' name='categories[".$key."]' value='".$value."'>";
						echo "<label for='".$value."'>".$value."</label><br>";
					}
				 }
				?>
			<br/>	
			<label> Published Date </label>
			<input type="text" class="form-control" name="p_date" id="p_date" value="<?php echo $p_date ?>" placeholder="YYYY-MM-DD" required> 
			 <br/>

			 <label> Review </label>
			<textarea rows = "5" cols = "50" class="form-control" name="review" id="review" required>
			<?php echo htmlspecialchars($review); ?></textarea>
				<br/>

				<label> ISBN Number </label>
			<input type="text" class="form-control" name="isbn" id="isbn" value="<?php echo $isbn ?>" required>
			<br/>

			<label> Price </label>
			<input type="number" class="form-control" name="price" id="price" value="<?php echo $price ?>" min="1" step="any" required />
			<br/>

			<label> Type </label>
			<select class="form-control" id="type" name="type" required>
				<option value="0">Select</option>
				<?php 
				foreach($type_arr as $key => $value){
					$isSelected ="";
					if($type == $key){
					  $isSelected = "selected";
					}
					echo '<option value="'.$key.'"'.$isSelected.'>'.$value.'</option>';
				 }
				?>
			</select> <br/>

			<label> Rating </label>
			<select class="form-control" id="rating" name="rating" required>
				<option value="0">Select</option>
				<?php 
				foreach($rating_arr as $key => $value){
					$isSelected ="";
					if($rating == $key){
					  $isSelected = "selected";
					}
					echo '<option value="'.$key.'"'.$isSelected.'>'.$value.'</option>';
				 }
				?>
			</select> <br/>

			<label> Book format </label><br>
			&emsp;<input <?php if ($paperback == 1) echo 'checked="checked"'; ?> type="checkbox" id="paperback" name="b_format[]" value="paperback">
			<label for="paperback">Paperback</label><br>
			&emsp;<input <?php if ($hardback == 1) echo 'checked="checked"'; ?> type="checkbox" id="hardback" name="b_format[]" value="hardback">
			<label for="hardback">Hardback</label><br>
			&emsp;<input <?php if ($ebook == 1) echo 'checked="checked"'; ?> type="checkbox" id="ebook" name="b_format[]" value="ebook">
			<label for="ebook">Ebook</label><br><br>

			<label> Availability </label><br>
			&emsp;<input <?php if ($availability == 1) echo 'checked="checked"'; ?> type="radio" id="available" name="availability" value="1" required>
			<label for="available">Available</label><br>
			&emsp;<input <?php if ($availability == 0) echo 'checked="checked"'; ?> type="radio" id="outofstock" name="availability" value="0">
			<label for="outofstock">Out of stock</label><br><br><br><br>

			 <?php if(isset($_GET['edit'])) { ?>
			<button type="submit" class="btn-primary btn-lg" name="update" id="update" style="margin-left:160px;"> Update</button>
			 <?php } else { ?>
			 <button type="submit" class="btn-primary btn-lg" name="save" id="save" style="margin-left:160px;"> Save</button>
			 <?php } ?>
			<button type="button" class="btn-primary btn-lg" name="cancle" id="cancle" > Cancle</button>
	
	</div>
	</form>
	
</body>
</html>