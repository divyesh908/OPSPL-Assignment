<?php
// connect to database
define('DB_HOST','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_NAME','opspltask_db');
date_default_timezone_set('Asia/Calcutta');
$link = mysqli_connect(DB_HOST, DB_USERNAME, DB_PASSWORD,DB_NAME)or die('Could not connect');

$category_arr=GetArray("Select cat_id, category from categories order by cat_id");
$type_arr = array("1"=>"Magazine", "2"=>"Novel", "3"=>"Textbook");
$rating_arr = array("1"=>"1", "2"=>"2", "3"=>"3", "4"=>"4", "5"=>"5");

function GetArray($q)
{
	global $link;
    $r = mysqli_query($link,$q);
	$numrow = mysqli_num_rows($r);
	$array=array();
	if($numrow)
	{	
		for($i=1; $row = mysqli_fetch_row($r); $i++)
		{ 
                $array[$row[0]]=$row[1]; 
        }
     }   
    return $array;
}     


if(isset($_POST["save"]))
	{
		$paperback=0;
		$hardback=0;
		$ebook=0;

		$b_name=$_POST["b_name"];
		$a_email=$_POST["a_email"];

		$target = "uploads/";
		$target = $target . basename( $_FILES['c_picture']['name']);
		$pic=($_FILES['c_picture']['name']);

		$categories=$_POST["categories"];
		$p_date=$_POST["p_date"];
		$review=$_POST["review"];
		$isbn=$_POST["isbn"];
		$price=$_POST["price"];
		$type=$_POST["type"];
		$rating=$_POST["rating"];
		$b_format = $_POST['b_format'];

		foreach ($b_format as $value){ 
			if($value=='paperback'){
				$paperback=1;
			} else if($value=='hardback'){
				$hardback=1;
			} else{
				$ebook=1;
			}
		}
		$availability=$_POST["availability"];
		$date = date('Y-m-d H:i:s');
		




		/***************** validation start ****************/
 
		if (!preg_match ("/^[a-zA-Z\s]+$/", $b_name) ) {    
			die('Only alphabets and whitespace are allowed in the book name field!');
		}  

		if (!preg_match ("/^[0-9]*$/", $price) ){  
			die('Only numeric value is allowed in the price field!');  
		}  

		if ($_FILES['c_picture']['size'] < 0) { 
			die('Please select the cover picture!');
		}

		if (($_FILES["c_picture"]["size"] > 2000000)) {
			die('Image File Size is Greater than 2MB!');
		} 
 
		$pattern = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^";  
		if (!preg_match ($pattern, $a_email) ){
			die('Please enter a valid email!'); 
		}

		/****************** validation end *****************/
		
		



		
		$query = "insert into books values 
		('','".$b_name."','".$a_email."','".$pic."','".$p_date."','".$review."','".$isbn."','".$price."','".$type."',
		'".$rating."','".$paperback."','".$hardback."','".$ebook."','".$availability."','".$date."')";

		if (mysqli_query($link,$query) === TRUE) {
			$last_id = $link->insert_id;

			foreach ($categories as $key => $value){ 
				$sub_query = "insert into book_categories values ('','".$last_id."','".$key."')";
				$sub_queryexe = mysqli_query($link,$sub_query);
			}	
		  } else {
			echo "Error: " . $query . "<br>" . $link->error;
		  }

		if(move_uploaded_file($_FILES['c_picture']['tmp_name'], $target))
		{//echo "The file ". basename( $_FILES['uploadedfile']['name']). " has been uploaded, and your information has been added to the directory";
		}

		header('location: home_page.php');
	}
 
 
	
	
	if(isset($_POST['update']))
	{
		$id=$_POST['id'];
		$paperback=0;
		$hardback=0;
		$ebook=0;

		$b_name=$_POST["b_name"];
		$a_email=$_POST["a_email"];

		$target = "uploads/";
		$target = $target . basename( $_FILES['c_picture']['name']);
		$pic=($_FILES['c_picture']['name']);

		$categories=$_POST["categories"];
		$p_date=$_POST["p_date"];
		$review=$_POST["review"];
		$isbn=$_POST["isbn"];
		$price=$_POST["price"];
		$type=$_POST["type"];
		$rating=$_POST["rating"];
		$b_format = $_POST['b_format'];

		foreach ($b_format as $value){ 
			if($value=='paperback'){
				$paperback=1;
			} else if($value=='hardback'){
				$hardback=1;
			} else{
				$ebook=1;
			}
		}
		$availability=$_POST["availability"];
		$date = date('Y-m-d H:i:s');
		



		/***************** validation start ****************/
 
		if (!preg_match ("/^[a-zA-Z\s]+$/", $b_name) ) {    
			die('Only alphabets and whitespace are allowed in the book name field!');
		}  

		if (!preg_match ("/^[0-9]*$/", $price) ){  
			die('Only numeric value is allowed in the price field!');  
		}  

		if ($_FILES['c_picture']['size'] < 0) { 
			die('Please select the cover picture!');
		}

		if (($_FILES["c_picture"]["size"] > 2000000)) {
			die('Image File Size is Greater than 2MB!');
		} 
 
		$pattern = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^";  
		if (!preg_match ($pattern, $a_email) ){
			die('Please enter a valid email!'); 
		}

		/****************** validation end *****************/





		mysqli_query($link,"update books set book_name='$b_name', author_email='$a_email', cover_picture = '$pic', 
		dt_publish='$p_date', review='$review', isbn_number='$isbn', price = '$price',
		type='$type', rating='$rating', is_paperback='$paperback', is_hardback = '$hardback', 
		is_ebook='$ebook', in_stock='$availability', dt_modified='$date' where book_id=$id");

		mysqli_query($link,"delete from book_categories where book_id=$id");

		foreach ($categories as $key => $value){ 
			$sub_query = "insert into book_categories values ('','".$id."','".$key."')";
			$sub_queryexe = mysqli_query($link,$sub_query);
		}	

		if(move_uploaded_file($_FILES['c_picture']['tmp_name'], $target))
		{//echo "The file ". basename( $_FILES['uploadedfile']['name']). " has been uploaded, and your information has been added to the directory";
		}
		
		header("location:home_page.php");
	}
	
	
	
	if(isset($_GET['delete']))
	 {
		$id=$_GET['delete'];
		mysqli_query($link,"delete from books where book_id=$id");
		mysqli_query($link,"delete from book_categories where book_id=$id");
		 
		header("location:home_page.php");
	 }


?>