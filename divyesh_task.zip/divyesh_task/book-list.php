<?php  
include ('server_page.php');
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Books</title>  
           <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		   <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
		   <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		   <script type="text/javascript"></script>
			
      </head>  
      <body>  
         <br /><br />
		   <div class="row ">
				<div class="col-md-1"></div>
			   <div class="col-md-3" >
				<a href="add_prod.php"><strong>Add New Book </strong></a>
				</div>
			</div>
			<br /><br />
           <div class="container" style="width:1000px;">  
                <h2 align="center">Book Listing</h3>  
                <br />  
                <br />
				<div id="prod">
					<?php 
						 $sql=" select * from books";
						$query = mysqli_query($link,$sql);
					
						echo"
						<div class='table-responsive '  style='overflow-y:hidden;' >
								<table id='tb' class='table  table-striped'>
									<tr>
										<th>Sr No. </th>
										<th>Book</th>
										<th>Book Cover</th>
										<th>Author </th>
										<th>Price </th>
										<th>Type </th>
										<th>Edit</th>
										<th>Delete</th>
									</tr>
						";
						$i=1;
						while($row = mysqli_fetch_row($query))
						{
							$type='';
							if($row[8]==1){
								$type = 'Magazine';
							} else if($row[8]==1) {
								$type = 'Novel';
							} else {
								$type = 'Textbook';
							}
							echo'
								<tr>
									<td>'.$i.'</td>
									<td>'.$row[1].'</td>
									<td> <img style="max-width: 100px;" src = "uploads/'.$row[3].'" /></td> 
									<td>'.$row[2].'</td>
									<td>'.$row[7].'</td>
									<td>'.$type.'</td>
									<td> <a href="add_prod.php?edit='.$row[0].'"> Edit </a> </td>
									<td> <a onclick="return confirm(\'Are you sure you want to delete this item?\')" href="server_page.php?delete='.$row[0].'"> Delete </a> </td>
								</tr>';
							$i++;
						}
					
						echo "</table> </div>";
					?>
				</div>	
           </div> 
		   
      </body>  
 </html>  
  